## Bài nộp: MI từ ECG 12 chuyển đạo (PTB-XL) — nhóm `nhomXX`

**Thư mục:** `submissions/<topic_slug>_nhomXX/` (PR chỉ thay đổi đúng thư mục này)

### Tóm tắt
Baseline đặc trưng lâm sàng (LR/GB) so với CNN 1D cho MI vs NORM; chống rò rỉ, CI bootstrap, hiệu chuẩn, phân tầng, Grad-CAM.

### Tái lập
`pip install -r requirements.txt && bash run_all.sh` (dữ liệu: PTB-XL từ PhysioNet, hướng dẫn trong README).

### Checklist (đối chiếu với mẫu PR thật của repo, điều chỉnh tên mục nếu khác)
- [x] Chỉ dùng dữ liệu công khai (PTB-XL); không có dữ liệu bệnh nhân thật
- [x] Chia tập theo bệnh nhân (strat_fold) + assert không rò rỉ
- [x] Scaler/imputer fit chỉ trên train; ngưỡng chọn trên val; test dùng một lần
- [x] Hạt giống cố định; lệnh tái lập trong README
- [x] Số liệu trong báo cáo sinh tự động từ `results/*.json`
- [x] Không commit khóa API, `.env`, file dữ liệu lớn
- [x] Thành viên dùng MSSV, không dùng họ tên
- [ ] Đã chạy `scripts/validate_submission.py` và `scripts/review_project.py` (tự tick sau khi chạy)
- [ ] Đã xóa `results_smoketest/` và sinh lại `report/report.md`, `slides/slides.pptx` từ kết quả thật
