"""Giải thích CNN: (1) Grad-CAM theo thời gian trên các ca MI đúng (TP); (2) tầm quan trọng từng chuyển đạo bằng che (occlusion).
Chạy sau train_cnn.py:  python src/gradcam.py --data data/ptb-xl"""
import argparse, json, os
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np, torch, torch.nn.functional as F
from sklearn.metrics import roc_auc_score
from common import FS, LEADS, get_data, split_masks
from train_cnn import Net, predict, prep


def main():
    a = argparse.ArgumentParser()
    a.add_argument("--data", default="data/ptb-xl"); a.add_argument("--out", default="results")
    a.add_argument("--synthetic", action="store_true"); a = a.parse_args()
    X, meta = get_data(a); tr, va, te = split_masks(meta); y = meta.y.values
    ck = torch.load(f"{a.out}/cnn_model.pt", weights_only=False)
    m = Net(); m.load_state_dict(ck["state"]); m.eval()
    Xn = prep(X[te], ck["mu"], ck["sd"]); yt = y[te]; p = predict(m, Xn, "cpu")
    thr = json.load(open(f"{a.out}/cnn_metrics.json"))["threshold_from_val"]

    # (1) Grad-CAM trên tối đa 4 ca TP có xác suất cao nhất
    tp = np.where((yt == 1) & (p >= thr))[0]; tp = tp[np.argsort(-p[tp])][:4]
    fig, axs = plt.subplots(len(tp), 4, figsize=(15, 2.6 * len(tp)), squeeze=False)
    for r, i in enumerate(tp):
        x = torch.from_numpy(Xn[i:i + 1]); feat = m.features(x); feat.retain_grad()
        m.fc(m.pool(feat).flatten(1)).squeeze().backward()
        cam = F.relu((feat.grad.mean(2, keepdim=True) * feat).sum(1, keepdim=True))
        cam = F.interpolate(cam, size=x.shape[2], mode="linear", align_corners=False)[0, 0].detach().numpy()
        cam = (cam - cam.min()) / (cam.max() - cam.min() + 1e-9); t = np.arange(x.shape[2]) / FS
        for c, l in enumerate(["II", "III", "V2", "V4"]):
            ax = axs[r, c]; sig = Xn[i, LEADS.index(l)]
            ax.imshow(cam[None], aspect="auto", cmap="Reds", alpha=0.55, extent=[0, t[-1], sig.min(), sig.max()])
            ax.plot(t, sig, "k", lw=0.8); ax.set_xlim(0, 5); ax.set_yticks([])
            ax.set_title(f"ca #{r + 1} · {l} · p={p[i]:.2f}", fontsize=9)
    plt.tight_layout(); plt.savefig(f"{a.out}/fig_gradcam.png", dpi=130); plt.close()

    # (2) Che từng chuyển đạo (đưa về giá trị trung bình = 0 sau chuẩn hóa) → mức giảm AUROC
    base = roc_auc_score(yt, p); drops = []
    for k in range(12):
        Xo = Xn.copy(); Xo[:, k] = 0
        drops.append(base - roc_auc_score(yt, predict(m, Xo, "cpu")))
    json.dump({"base_auroc": base, "auroc_drop_by_lead": dict(zip(LEADS, map(float, drops)))},
              open(f"{a.out}/lead_occlusion.json", "w"), indent=2)
    plt.figure(figsize=(7, 3.2)); plt.bar(LEADS, drops, color="#c0392b"); plt.ylabel("Giảm AUROC khi che chuyển đạo")
    plt.tight_layout(); plt.savefig(f"{a.out}/fig_lead_occlusion.png", dpi=130)


if __name__ == "__main__":
    main()
