"""Sinh report/report.md từ results/*.json để số liệu trong báo cáo LUÔN khớp output của code.
Chạy: python src/make_report.py   (sau train_baseline.py, train_cnn.py, analyze.py, gradcam.py)"""
import argparse, json, os

LABEL = {"lr": "Logistic Regression (đặc trưng thủ công)", "hgb": "Gradient Boosting (đặc trưng thủ công)", "cnn": "CNN 1D (end-to-end)"}


def ci(M, k, d=3):
    return f"{M['test'][k]:.{d}f} ({M['ci95'][k][0]:.{d}f}–{M['ci95'][k][1]:.{d}f})"


def main():
    a = argparse.ArgumentParser()
    a.add_argument("--results", default="results"); a.add_argument("--out", default="report/report.md")
    a.add_argument("--smoke", action="store_true", help="đánh dấu số liệu là MÔ PHỎNG")
    a = a.parse_args(); R = a.results
    J = lambda f: json.load(open(f"{R}/{f}")) if os.path.exists(f"{R}/{f}") else None
    S, A = J("data_stats.json"), J("analysis.json")
    M = {n: J(f"{n}_metrics.json") for n in LABEL if J(f"{n}_metrics.json")}
    fig = lambda f, cap: f"![{cap}](../{R}/{f})\n\n*{cap}*\n" if os.path.exists(f"{R}/{f}") else ""
    main_m = A["main_model"]
    L = []
    if a.smoke:
        L.append("> ⚠️ **BẢN XEM THỬ TRÊN DỮ LIỆU MÔ PHỎNG** — số liệu dưới đây chỉ chứng minh đường ống chạy được, "
                 "KHÔNG phải kết quả khoa học. Chạy lại trên PTB-XL thật rồi sinh lại báo cáo trước khi nộp.\n")
    L.append("# Phát hiện nhồi máu cơ tim cấp/cũ (MI) từ ECG 12 chuyển đạo trên PTB-XL\n")
    L.append("**Nhóm:** nhomXX · Thành viên: xem `submission.json` (định danh bằng MSSV)\n")
    L.append("""## 1. Đặt vấn đề và ý nghĩa lâm sàng

Nhồi máu cơ tim (MI) là hoại tử cơ tim do thiếu máu cục bộ; ECG 12 chuyển đạo là xét nghiệm đầu tay vì nhanh, rẻ và không xâm lấn
[@thygesen2018universal]. Dấu hiệu điển hình gồm chênh lên/xuống đoạn ST, sóng Q bệnh lý và biến đổi sóng T ở các chuyển đạo thuộc cùng một vùng
cơ tim (thành trước: V1–V4; thành dưới: II, III, aVF; thành bên: I, aVL, V5–V6). Việc đọc ECG phụ thuộc kinh nghiệm người đọc và dễ bỏ sót ở ca
tinh tế, nên hệ thống hỗ trợ chẩn đoán tự động có giá trị trong sàng lọc và ở nơi thiếu bác sĩ tim mạch.

**Bài toán:** phân loại nhị phân bản ghi ECG 10 giây, 12 chuyển đạo thành *MI* hay *bình thường (NORM)*.
**Mục tiêu:** (i) xây dựng baseline dựa trên đặc trưng lâm sàng có thể giải thích; (ii) huấn luyện CNN 1D end-to-end;
(iii) so sánh công bằng giữa hai hướng với quy trình chống rò rỉ dữ liệu; (iv) đánh giá hiệu chuẩn, phân tầng theo nhóm bệnh nhân và giải thích mô hình.
""")
    tr, va, te = S["train"], S["val"], S["test"]
    L.append(f"""## 2. Dữ liệu

Dùng **PTB-XL v1.0.3** [@wagner2020ptbxl], công khai trên PhysioNet [@goldberger2000physionet] (giấy phép CC BY 4.0), gồm ECG 12 chuyển đạo, 10 giây,
chuẩn bị ở 100 Hz và 500 Hz; bài này dùng bản **100 Hz** (1000 mẫu/chuyển đạo). Nhãn lấy từ `scp_codes` → `diagnostic_class`:
**MI** nếu có mã thuộc lớp MI; **NORM** nếu chỉ thuộc lớp NORM; các bản ghi thuộc lớp khác (STTC, CD, HYP) hoặc đa nhãn lẫn bị loại.
Do đó bài toán là *MI vs NORM* (không có hard negatives như STTC), điều này làm kết quả lạc quan hơn tình huống lâm sàng thật (xem mục 5).

Sau lọc còn **{S['n_total']}** bản ghi của **{S['n_patients']}** bệnh nhân (MI {100 * S['prevalence_MI']:.1f}%). Tuổi {S['age_mean_sd'][0]:.1f} ± {S['age_mean_sd'][1]:.1f}; nữ {S['female_pct']:.1f}%.
Phân bố vùng MI: {', '.join(f"{ {'truoc':'thành trước','duoi':'thành dưới','khac':'vùng khác'}[k]}: {v}" for k, v in S['MI_location_counts'].items())}.

| Tập | Fold (strat_fold) | Số bản ghi | Số bệnh nhân | MI (n) | MI (%) |
|---|---|---|---|---|---|
| Train | 1–8 | {tr['n']} | {tr['n_patients']} | {tr['n_MI']} | {tr['MI_pct']:.1f} |
| Val | 9 | {va['n']} | {va['n_patients']} | {va['n_MI']} | {va['MI_pct']:.1f} |
| Test | 10 | {te['n']} | {te['n_patients']} | {te['n_MI']} | {te['MI_pct']:.1f} |

**Kiểm tra rò rỉ bệnh nhân:** số bệnh nhân chung train–val / train–test / val–test = {S['patient_overlap']['train_val']} / {S['patient_overlap']['train_test']} / {S['patient_overlap']['val_test']} (code `assert` bằng 0 trước khi huấn luyện).
""")
    L.append("""## 3. Phương pháp

**3.1 Chống rò rỉ dữ liệu.** (a) Chia tập theo `strat_fold` chính thức của PTB-XL — các bản ghi cùng bệnh nhân nằm cùng một fold [@wagner2020ptbxl];
train = fold 1–8, val = fold 9, test = fold 10. (b) Mọi phép chuẩn hóa (trung bình/độ lệch chuẩn theo chuyển đạo, imputer, scaler) **chỉ fit trên train**.
(c) Siêu tham số, epoch tốt nhất và **ngưỡng quyết định (chỉ số Youden)** chọn trên val. (d) Test chỉ đánh giá một lần. (e) Không dùng SMOTE; mất cân bằng lớp xử lý bằng `class_weight`/`pos_weight`.

**3.2 Baseline đặc trưng lâm sàng.** Lọc thông cao 0.5 Hz (zero-phase) để bỏ trôi đường nền; dò đỉnh R bằng năng lượng băng 5–15 Hz; lấy **nhịp trung vị** (R−200 ms … R+500 ms);
tính cho mỗi chuyển đạo 5 đặc trưng so với đoạn PR: biên độ R, cực tiểu QRS, sóng Q, đoạn ST tại ~J+60 ms, sóng T (giá trị có biên độ lớn nhất), cộng nhịp tim, độ lệch chuẩn RR và số nhịp
(63 đặc trưng). Mô hình: Logistic Regression (chuẩn hóa, `C ∈ {0.01, 0.1, 1}`) và HistGradientBoosting (`max_depth ∈ {3, 6}`, `lr ∈ {0.05, 0.1}`), chọn theo AUROC trên val.

**3.3 CNN 1D.** Bốn khối Conv1D–BatchNorm–ReLU–MaxPool (32→64→128→128 kênh, kernel 7/7/5/5), Global Average Pooling, Dropout 0.3, đầu ra 1 logit. Loss BCE có `pos_weight`;
AdamW (lr 1e-3, weight decay 1e-4), cosine schedule, 30 epoch, batch 64; tăng cường dữ liệu: nhân biên độ ±10%, nhiễu Gaussian σ = 0.02 (đơn vị đã chuẩn hóa), dịch thời gian ±0.5 s; hạt giống 42.

**3.4 Đánh giá.** AUROC, AUPRC, độ nhạy, độ đặc hiệu, PPV, NPV, F1 tại ngưỡng cố định từ val; **khoảng tin cậy 95% bootstrap** (1000 lần, lấy mẫu lại bản ghi test);
hiệu chuẩn bằng Brier và ECE (10 bin). So sánh hai mô hình bằng bootstrap cặp trên hiệu AUROC. Phân tầng theo giới, nhóm tuổi và vùng MI (thành trước/dưới/khác).
Giải thích CNN bằng Grad-CAM [@selvaraju2017gradcam] và che từng chuyển đạo (occlusion).
""")
    rows = "\n".join(f"| {LABEL[n]} | {ci(m,'auroc')} | {ci(m,'auprc')} | {ci(m,'sens')} | {ci(m,'spec')} | {ci(m,'ppv')} | {m['brier']:.3f} | {m['ece']:.3f} |"
                     for n, m in M.items())
    L.append(f"""## 4. Kết quả

Tập test: **{M[main_m]['n_test']}** bản ghi (MI = {M[main_m]['n_test_MI']}). Số trong ngoặc là khoảng tin cậy 95%.

| Mô hình | AUROC | AUPRC | Độ nhạy | Độ đặc hiệu | PPV | Brier | ECE |
|---|---|---|---|---|---|---|---|
{rows}

Mô hình chính (chọn theo AUROC trên **val**, không nhìn test): **{LABEL[main_m]}**; ngưỡng {M[main_m]['threshold_from_val']:.3f} chọn trên val.

{fig('fig_roc.png','Hình 1. Đường cong ROC trên tập test')}
{fig('fig_pr.png','Hình 2. Đường cong Precision–Recall trên tập test')}
{fig('fig_calibration.png','Hình 3. Biểu đồ hiệu chuẩn')}
{fig('fig_confusion.png','Hình 4. Ma trận nhầm lẫn của mô hình chính tại ngưỡng từ val')}
""")
    c = A.get("compare")
    if c:
        sig = "khoảng tin cậy không chứa 0 → khác biệt có ý nghĩa thống kê ở mức 5%" if (c["ci95"][0] > 0 or c["ci95"][1] < 0) \
            else "khoảng tin cậy chứa 0 → chưa đủ bằng chứng để khẳng định hai mô hình khác nhau"
        L.append(f"**So sánh {c['a'].upper()} − {c['b'].upper()}:** ΔAUROC = {c['diff']:+.3f} (95% CI {c['ci95'][0]:+.3f} đến {c['ci95'][1]:+.3f}); {sig}.\n")
    sg = A["subgroups"]
    def f_auc(v): return "—" if not v else f"{v[0]:.3f} ({v[1]:.3f}–{v[2]:.3f})"
    sub_rows = "\n".join(f"| {k} | {v.get('n', '—')} | {v['n_MI']} | {f_auc(v['auroc_ci'])} | {'—' if v.get('sens') is None else format(v['sens'], '.3f')} |" for k, v in sg.items())
    L.append(f"""### 4.1 Phân tầng theo nhóm bệnh nhân ({LABEL[main_m]})

| Nhóm | n | MI | AUROC (95% CI) | Độ nhạy tại ngưỡng |
|---|---|---|---|---|
{sub_rows}

(Với nhóm vùng MI, AUROC tính trên các ca MI vùng đó so với toàn bộ NORM của test; nhóm nhỏ → CI rộng, cần thận trọng khi diễn giải.)
""")
    if "lr" in M and "top_features" in M["lr"]:
        L.append("### 4.2 Đặc trưng quan trọng của baseline\n\nLogistic Regression (hệ số chuẩn hóa lớn nhất): " +
                 ", ".join(f"`{n}` ({v:+.2f})" for n, v in M["lr"]["top_features"][:6]) + ".")
    if "hgb" in M and "top_features" in M["hgb"]:
        L.append("\nGradient Boosting (permutation importance trên val): " + ", ".join(f"`{n}` ({v:.3f})" for n, v in M["hgb"]["top_features"][:6]) +
                 ".\nKỳ vọng lâm sàng: các đặc trưng đoạn ST, sóng Q và sóng T ở chuyển đạo của vùng tổn thương nên xuất hiện trong nhóm đứng đầu; nếu không, cần kiểm tra lại bước dò nhịp.\n")
    occ = J("lead_occlusion.json")
    if occ:
        top = sorted(occ["auroc_drop_by_lead"].items(), key=lambda t: -t[1])[:3]
        L.append("### 4.3 Giải thích CNN\n\n" + fig("fig_gradcam.png", "Hình 5. Grad-CAM trên các ca MI được phát hiện đúng (vùng đỏ = mô hình chú ý)") +
                 fig("fig_lead_occlusion.png", "Hình 6. Mức giảm AUROC khi che từng chuyển đạo") +
                 f"Che chuyển đạo làm AUROC giảm nhiều nhất ở: " + ", ".join(f"{k} (−{v:.3f})" for k, v in top) +
                 ". Cần đối chiếu với vùng MI phổ biến trong dữ liệu; Grad-CAM chỉ cho biết *thời điểm* mô hình chú ý, không phải bằng chứng nhân quả.\n")
    best = max(M, key=lambda n: M[n]["test"]["auroc"])
    L.append(f"""## 5. Thảo luận và hạn chế

**Nhận xét chính.** Trên tập test, mô hình có AUROC cao nhất là {LABEL[best]} ({ci(M[best],'auroc')}). {'Hai hướng tiếp cận cho hiệu năng ' + ('khác biệt có ý nghĩa' if c and (c['ci95'][0] > 0 or c['ci95'][1] < 0) else 'chưa khác biệt rõ ràng') + ' khi xét khoảng tin cậy bootstrap cặp.' if c else ''}
Độ nhạy/độ đặc hiệu phụ thuộc ngưỡng; ngưỡng Youden từ val cân bằng hai chỉ số, còn ứng dụng sàng lọc có thể ưu tiên độ nhạy cao hơn.

**Hạn chế.**
1. *Bài toán dễ hơn thực tế:* chỉ MI vs NORM, đã loại STTC/CD/HYP — những dạng dễ nhầm với MI; hiệu năng ngoài thực tế (phân biệt MI với mọi ECG bất thường khác) thấp hơn.
2. *Nhãn không phải chuẩn vàng:* nhãn PTB-XL do bác sĩ/thuật toán gán từ ECG, không đối chiếu men tim hay chụp mạch vành; MI cũ và MI cấp gộp chung.
3. *Một nguồn dữ liệu:* PTB-XL thu thập tại một hệ thống với thiết bị Schiller trong những năm 1989–1996 [@wagner2020ptbxl]; chưa có kiểm định ngoài (ví dụ trên bộ dữ liệu khác) nên khả năng tổng quát hóa chưa được chứng minh.
4. *Một lần chia tập và một hạt giống:* CI bootstrap phản ánh sai số lấy mẫu test, không phản ánh biến thiên do khởi tạo/chia tập; nên lặp nhiều seed hoặc cross-validation theo fold nếu có thời gian.
5. *Nhóm con nhỏ:* phân tầng theo vùng MI/tuổi có CI rộng.
6. *Đặc trưng thủ công phụ thuộc dò nhịp:* ECG nhiễu có thể dò sai nhịp, làm sai đặc trưng ST/Q.
So sánh số liệu với benchmark [@strodthoff2021benchmark] chỉ mang tính tham khảo vì khác định nghĩa bài toán (nhị phân MI vs NORM so với phân loại siêu lớp).

## 6. Kết luận

Đã xây dựng đường ống tái lập được cho phát hiện MI từ ECG 12 chuyển đạo với chia tập theo bệnh nhân, chuẩn hóa chỉ trên train, ngưỡng chọn trên val, CI bootstrap, đánh giá hiệu chuẩn,
phân tầng nhóm bệnh nhân và giải thích mô hình. Hướng phát triển: kiểm định ngoài, bao gồm hard negatives (STTC/CD), mô hình dạng ResNet/Transformer với dữ liệu 500 Hz, nhiều seed, hiệu chuẩn sau huấn luyện (temperature scaling).

## 7. Đạo đức và tái lập

Chỉ dùng dữ liệu công khai PTB-XL (đã ẩn danh hóa; tuổi > 89 được PTB-XL mã hóa thành 300 và code đặt về NaN); không có PHI, khóa API hay dữ liệu bệnh nhân thật trong repo.
Dữ liệu không được commit — tải theo hướng dẫn trong `README.md`. Mô hình chỉ phục vụ nghiên cứu/học tập, **không phải thiết bị chẩn đoán**. Lệnh tái lập: `bash run_all.sh`; hạt giống 42.

## Tài liệu tham khảo

Các citekey trong báo cáo khớp `report/refs.bib`:
`wagner2020ptbxl` (Wagner et al., *Sci Data* 2020, doi:10.1038/s41597-020-0495-6) ·
`strodthoff2021benchmark` (Strodthoff et al., *IEEE JBHI* 2021, doi:10.1109/JBHI.2020.3022989) ·
`goldberger2000physionet` (Goldberger et al., *Circulation* 2000, doi:10.1161/01.CIR.101.23.e215) ·
`thygesen2018universal` (Thygesen et al., *Circulation* 2018, doi:10.1161/CIR.0000000000000617) ·
`selvaraju2017gradcam` (Selvaraju et al., *ICCV* 2017, doi:10.1109/ICCV.2017.74).
""")
    os.makedirs(os.path.dirname(a.out), exist_ok=True)
    open(a.out, "w").write("\n".join(L)); print("đã ghi", a.out)


if __name__ == "__main__":
    main()
