"""Đặc trưng lâm sàng thủ công từ nhịp trung vị: biên độ R, Q, đoạn ST (J+60ms), sóng T mỗi chuyển đạo."""
import numpy as np
from scipy.signal import butter, find_peaks, sosfiltfilt
from common import FS, LEADS

PRE, POST = 20, 50      # cửa sổ nhịp: R-200ms → R+500ms (100 Hz)
FEAT = ["r", "qrs_min", "q", "st", "t"]
NAMES = [f"{l}_{f}" for l in LEADS for f in FEAT] + ["hr", "rr_std", "n_beats"]


def _beats(x, fs=FS):
    sos_bp = butter(2, [5, 15], "band", fs=fs, output="sos")
    e = (sosfiltfilt(sos_bp, x, axis=0) ** 2).sum(1)
    e = np.convolve(e, np.ones(9) / 9, "same")
    p, _ = find_peaks(e, height=0.3 * e.max(), distance=int(0.3 * fs))
    return p[(p >= PRE) & (p + POST <= len(x))]


def extract(x, fs=FS):
    """x: (T, 12) → vector (63,). NaN nếu không dò được nhịp."""
    f = np.full(len(NAMES), np.nan)
    x = sosfiltfilt(butter(2, 0.5, "high", fs=fs, output="sos"), x, axis=0)   # bỏ trôi đường nền (zero-phase)
    p = _beats(x)
    if len(p) < 2: return f
    win = np.median(np.stack([x[i - PRE:i + POST] for i in p]), axis=0)        # (70, 12)
    base = win[PRE - 14:PRE - 8].mean(0)                                         # đoạn PR
    w = win - base
    r_ = w[PRE - 4:PRE + 5]
    cols = [r_.max(0), r_.min(0), w[PRE - 9:PRE - 2].min(0), w[PRE + 9:PRE + 14].mean(0)]
    tw = w[PRE + 15:PRE + 45]; cols.append(tw[np.abs(tw).argmax(0), np.arange(12)])
    f[:60] = np.stack(cols, 1).ravel()
    rr = np.diff(p) / fs
    f[60:] = [60 / rr.mean(), rr.std(), len(p)]
    return f


def extract_all(X, cache=None):
    import os
    if cache and os.path.exists(cache): return np.load(cache)["F"]
    F = np.stack([extract(x) for x in X])
    if cache: np.savez_compressed(cache, F=F)
    return F
