"""Phân tích sau huấn luyện: ROC/PR/hiệu chuẩn/ma trận nhầm lẫn, so sánh mô hình (bootstrap cặp), phân tầng theo giới/tuổi/vùng MI.
Chạy: python src/analyze.py --data data/ptb-xl"""
import argparse, glob, json, os
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from sklearn.metrics import precision_recall_curve, roc_auc_score, roc_curve
from common import SEED, get_data, paired_auc_diff

LABEL = {"lr": "Logistic Regression", "hgb": "Gradient Boosting", "cnn": "CNN 1D"}


def auc_ci(y, p, n=500):
    if len(y) < 20 or y.min() == y.max(): return None
    rng = np.random.default_rng(SEED); v = []
    for _ in range(n):
        i = rng.integers(0, len(y), len(y))
        if y[i].min() != y[i].max(): v.append(roc_auc_score(y[i], p[i]))
    return [float(roc_auc_score(y, p)), float(np.percentile(v, 2.5)), float(np.percentile(v, 97.5))]


def main():
    a = argparse.ArgumentParser()
    a.add_argument("--data", default="data/ptb-xl"); a.add_argument("--out", default="results")
    a.add_argument("--synthetic", action="store_true"); a = a.parse_args()
    _, meta = get_data(a)
    P = {n: np.load(f"{a.out}/{n}_preds.npz") for n in ("lr", "hgb", "cnn") if os.path.exists(f"{a.out}/{n}_preds.npz")}
    M = {n: json.load(open(f"{a.out}/{n}_metrics.json")) for n in P}
    main_m = max(M, key=lambda n: M[n]["val_auroc"])            # chọn mô hình chính theo VAL (không nhìn test)
    out = {"main_model": main_m, "models": list(P)}
    y = P[main_m]["y_test"]

    # đường cong
    for kind in ("roc", "pr"):
        plt.figure(figsize=(4.6, 4.2))
        for n, z in P.items():
            if kind == "roc": f, t, _ = roc_curve(z["y_test"], z["p_test"]); plt.plot(f, t, label=f"{LABEL[n]} ({M[n]['test']['auroc']:.3f})")
            else: pr, rc, _ = precision_recall_curve(z["y_test"], z["p_test"]); plt.plot(rc, pr, label=f"{LABEL[n]} ({M[n]['test']['auprc']:.3f})")
        if kind == "roc": plt.plot([0, 1], [0, 1], "k:", lw=.8); plt.xlabel("1 - Độ đặc hiệu"); plt.ylabel("Độ nhạy")
        else: plt.xlabel("Recall"); plt.ylabel("Precision")
        plt.legend(fontsize=8); plt.tight_layout(); plt.savefig(f"{a.out}/fig_{kind}.png", dpi=130); plt.close()
    plt.figure(figsize=(4.4, 4.2)); plt.plot([0, 1], [0, 1], "k:", lw=.8)
    for n, z in P.items():
        b = np.minimum((z["p_test"] * 10).astype(int), 9)
        xs = [z["p_test"][b == k].mean() for k in range(10) if (b == k).sum() >= 5]
        ys = [z["y_test"][b == k].mean() for k in range(10) if (b == k).sum() >= 5]
        plt.plot(xs, ys, "o-", ms=3, label=f"{LABEL[n]} (ECE={M[n]['ece']:.3f})")
    plt.xlabel("Xác suất dự đoán"); plt.ylabel("Tỉ lệ MI thực tế"); plt.legend(fontsize=8); plt.tight_layout()
    plt.savefig(f"{a.out}/fig_calibration.png", dpi=130); plt.close()
    t = M[main_m]["test"]; cm = np.array([[t["tn"], t["fp"]], [t["fn"], t["tp"]]])
    plt.figure(figsize=(3.6, 3.2)); plt.imshow(cm, cmap="Blues")
    for i in range(2):
        for j in range(2): plt.text(j, i, cm[i, j], ha="center", va="center", color="w" if cm[i, j] > cm.max() / 2 else "k")
    plt.xticks([0, 1], ["NORM", "MI"]); plt.yticks([0, 1], ["NORM", "MI"]); plt.xlabel("Dự đoán"); plt.ylabel("Thực tế")
    plt.title(LABEL[main_m], fontsize=9); plt.tight_layout(); plt.savefig(f"{a.out}/fig_confusion.png", dpi=130); plt.close()

    # so sánh mô hình (bootstrap cặp)
    out["compare"] = {}
    others = [n for n in P if n != "cnn"]
    if "cnn" in P and others:
        bestb = max(others, key=lambda n: M[n]["val_auroc"])
        out["compare"] = {"a": "cnn", "b": bestb, **paired_auc_diff(P["cnn"]["y_test"], P["cnn"]["p_test"], P[bestb]["p_test"])}
    elif len(P) > 1:
        ns = sorted(P, key=lambda n: -M[n]["val_auroc"]); out["compare"] = {"a": ns[0], "b": ns[1], **paired_auc_diff(P[ns[0]]["y_test"], P[ns[0]]["p_test"], P[ns[1]]["p_test"])}

    # phân tầng (mô hình chính, ngưỡng cố định từ val)
    m = meta.iloc[P[main_m]["test_idx"]].reset_index(drop=True); p = P[main_m]["p_test"]; thr = M[main_m]["threshold_from_val"]
    sub = {}
    groups = {"Giới: nam": m.sex == 0, "Giới: nữ": m.sex == 1, "Tuổi < 50": m.age < 50,
              "Tuổi 50–69": (m.age >= 50) & (m.age < 70), "Tuổi ≥ 70": m.age >= 70}
    for g, mk in groups.items():
        mk = mk.values; sub[g] = {"n": int(mk.sum()), "n_MI": int(y[mk].sum()), "auroc_ci": auc_ci(y[mk], p[mk])}
    for loc, name in (("truoc", "MI thành trước"), ("duoi", "MI thành dưới"), ("khac", "MI vùng khác")):
        mk = ((m["loc"] == loc) | (m["loc"] == "NORM")).values
        pos = (m["loc"] == loc).values
        sub[name] = {"n_MI": int(pos.sum()), "sens": float((p[pos] >= thr).mean()) if pos.any() else None,
                     "auroc_ci": auc_ci(y[mk], p[mk])}
    out["subgroups"] = sub
    json.dump(out, open(f"{a.out}/analysis.json", "w"), indent=2, ensure_ascii=False)
    print("mô hình chính:", main_m, "| so sánh:", out["compare"])


if __name__ == "__main__":
    main()
