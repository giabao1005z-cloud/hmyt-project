"""Baseline: đặc trưng lâm sàng thủ công (ST, Q, R, T mỗi chuyển đạo) + Logistic Regression / Gradient Boosting.
Fit chỉ trên train; siêu tham số chọn theo AUROC trên val; test chỉ đánh giá 1 lần.
Chạy: python src/train_baseline.py --data data/ptb-xl      (hoặc --synthetic để kiểm thử)"""
import argparse, json, os
import numpy as np
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.impute import SimpleImputer
from sklearn.inspection import permutation_importance
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from common import SEED, data_stats, finalize, get_data, split_masks
from features import NAMES, extract_all


def main():
    a = argparse.ArgumentParser()
    a.add_argument("--data", default="data/ptb-xl"); a.add_argument("--out", default="results")
    a.add_argument("--synthetic", action="store_true")
    a = a.parse_args(); os.makedirs(a.out, exist_ok=True)
    X, meta = get_data(a)
    json.dump(data_stats(meta), open(f"{a.out}/data_stats.json", "w"), indent=2, ensure_ascii=False)
    tr, va, te = split_masks(meta); y = meta.y.values
    F = extract_all(X, f"{a.out}/features.npz")
    print("đặc trưng:", F.shape, "| tỉ lệ NaN:", float(np.isnan(F).mean()))

    models = {
        "lr": [(f"C={C}", make_pipeline(SimpleImputer(strategy="median"), StandardScaler(),
                LogisticRegression(C=C, class_weight="balanced", max_iter=2000))) for C in (0.01, 0.1, 1.0)],
        "hgb": [(f"depth={d},lr={l}", HistGradientBoostingClassifier(max_depth=d, learning_rate=l, max_iter=300,
                class_weight="balanced", random_state=SEED)) for d in (3, 6) for l in (0.05, 0.1)],
    }
    for name, cands in models.items():
        best = max(((roc_auc_score(y[va], m.fit(F[tr], y[tr]).predict_proba(F[va])[:, 1]), n, m) for n, m in cands),
                   key=lambda t: t[0])
        print(f"[{name}] chọn {best[1]} (val AUROC={best[0]:.4f})")
        m = best[2]
        res = finalize(name, y[va], m.predict_proba(F[va])[:, 1], y[te], m.predict_proba(F[te])[:, 1],
                       np.where(te)[0], a.out)
        res["chosen_hparams"] = best[1]
        if name == "lr":
            coef = m[-1].coef_[0]; top = np.argsort(-np.abs(coef))[:10]
            imp = [(NAMES[i], float(coef[i])) for i in top]
        else:
            pi = permutation_importance(m, F[va], y[va], scoring="roc_auc", n_repeats=3, random_state=SEED)
            top = np.argsort(-pi.importances_mean)[:10]; imp = [(NAMES[i], float(pi.importances_mean[i])) for i in top]
        res["top_features"] = imp
        json.dump(res, open(f"{a.out}/{name}_metrics.json", "w"), indent=2)


if __name__ == "__main__":
    main()
