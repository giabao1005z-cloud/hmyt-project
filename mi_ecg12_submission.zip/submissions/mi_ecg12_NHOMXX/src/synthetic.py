"""Sinh ECG 12 chuyển đạo MÔ PHỎNG (có ST chênh, sóng Q bệnh lý theo vùng) để kiểm thử đường ống.
Số liệu chạy trên dữ liệu này KHÔNG có giá trị khoa học và không được dùng trong báo cáo."""
import numpy as np, pandas as pd

BASE_R = np.array([0.7, 1.1, 0.5, -0.8, 0.3, 0.8, 0.3, 0.9, 1.3, 1.5, 1.2, 0.9])
REGIONS = {"truoc": [6, 7, 8, 9], "duoi": [1, 2, 5], "khac": [0, 4, 10, 11]}


def _g(t, c, w): return np.exp(-0.5 * ((t - c) / w) ** 2)


def make_synthetic(n=1200, T=1000, fs=100, seed=0, prev=0.37):
    rng = np.random.default_rng(seed)
    t = np.arange(T) / fs
    X = np.zeros((n, T, 12), np.float32)
    n_pat = int(n * 0.8)
    pid = rng.integers(0, n_pat, n)
    fold = (pid % 10) + 1                       # cùng bệnh nhân → cùng fold (giống PTB-XL)
    y = (rng.random(n) < prev).astype(int)
    loc = np.array(["NORM"] * n, dtype=object)
    for i in range(n):
        hr = np.clip(rng.normal(70, 12), 45, 115)
        beats, tb = [], rng.uniform(0.2, 0.8)
        while tb < t[-1] - 0.6:
            beats.append(tb); tb += 60 / hr * rng.normal(1, 0.05)
        comp = {k: np.zeros(T) for k in "PQRSVT"}      # V = đoạn ST
        for b in beats:
            u = t - b
            comp["P"] += _g(u, -0.16, 0.025); comp["Q"] += _g(u, -0.03, 0.01); comp["R"] += _g(u, 0, 0.012)
            comp["S"] += _g(u, 0.03, 0.012); comp["V"] += _g(u, 0.13, 0.05) * (u > 0.04); comp["T"] += _g(u, 0.30, 0.045)
        a = BASE_R * rng.lognormal(0, 0.2)
        G = {"P": 0.10 * np.sign(a) * (np.abs(a) > .2), "Q": -0.10 * np.abs(a), "R": a, "S": -0.15 * np.abs(a),
             "V": np.zeros(12), "T": 0.25 * np.sign(a) * np.maximum(np.abs(a), .3)}
        if y[i]:
            r = rng.choice(list(REGIONS), p=[.45, .4, .15]); loc[i] = r
            L = REGIONS[r]; s = rng.uniform(0.0, 0.10)           # cường độ yếu → chồng lấn với NORM
            G["V"][L] += s * rng.uniform(0.7, 1.3, len(L))
            G["Q"][L] -= rng.uniform(0.0, 0.12) * np.abs(a[L])
            if rng.random() < 0.25: G["T"][L] *= -0.6
        sig = sum(np.outer(comp[k], G[k]) for k in comp)
        sig += 0.1 * np.sin(2 * np.pi * 0.3 * t + rng.uniform(0, 6))[:, None] + rng.normal(0, rng.uniform(0.02, 0.06), (T, 12))
        X[i] = sig
    meta = pd.DataFrame({"y": y, "fold": fold, "pid": pid, "age": rng.normal(60, 15, n),
                         "sex": rng.integers(0, 2, n), "loc": loc.astype(str)})
    return X, meta
