# Phát hiện nhồi máu cơ tim (MI) từ ECG 12 chuyển đạo (PTB-XL)

Nhóm: `nhomXX` (thành viên: xem `submission.json`, định danh bằng MSSV).
So sánh **baseline đặc trưng lâm sàng** (LR / Gradient Boosting) với **CNN 1D** cho bài toán MI vs NORM, có chống rò rỉ dữ liệu,
CI bootstrap, hiệu chuẩn, phân tầng nhóm bệnh nhân và giải thích mô hình (Grad-CAM, che chuyển đạo).

## Cấu trúc
```
submission.json        thông tin nhóm (điền slug, mã nhóm, MSSV)
src/common.py          nạp PTB-XL, chia tập, chỉ số, bootstrap CI
src/features.py        đặc trưng R/Q/ST/T theo nhịp trung vị
src/train_baseline.py  Logistic Regression + Gradient Boosting
src/train_cnn.py       CNN 1D (PyTorch)
src/analyze.py         ROC/PR/hiệu chuẩn, so sánh mô hình, phân tầng
src/gradcam.py         Grad-CAM + occlusion chuyển đạo
src/make_report.py     sinh report/report.md từ results/*.json
src/synthetic.py       ECG mô phỏng để kiểm thử (KHÔNG dùng cho báo cáo)
slides/build_slides.py sinh slides/slides.pptx từ results/
report/                report.md, refs.bib, van_dap.md
run_all.sh             chạy toàn bộ
```

## Dữ liệu (không commit vào repo)
PTB-XL v1.0.3, CC BY 4.0: https://physionet.org/content/ptb-xl/1.0.3/ — giải nén vào `data/ptb-xl/`
(cần `ptbxl_database.csv`, `scp_statements.csv`, thư mục `records100/`). `data/` đã nằm trong `.gitignore`.

## Chạy lại
```
pip install -r requirements.txt
bash run_all.sh                 # PTB-XL thật: ~vài phút baseline + huấn luyện CNN (nên dùng GPU)
bash run_all.sh --synthetic     # kiểm thử đường ống nhanh trên dữ liệu mô phỏng → results_smoketest/
```
Kết quả: `results/*_metrics.json`, `results/fig_*.png`; báo cáo và slide được **sinh tự động** từ các file này nên số liệu luôn khớp output của code.

## Thiết kế chống rò rỉ
- Chia theo `strat_fold` chính thức (cùng bệnh nhân → cùng fold); code `assert` không có bệnh nhân chung giữa train/val/test.
- Chuẩn hóa/imputer/scaler chỉ fit trên train; siêu tham số, epoch, ngưỡng Youden chọn trên val; test dùng một lần; không SMOTE.
- Hạt giống cố định 42.

## Lưu ý
Mô hình chỉ phục vụ học tập/nghiên cứu, không phải thiết bị chẩn đoán.
