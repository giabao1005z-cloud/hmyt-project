> ⚠️ **BẢN XEM THỬ TRÊN DỮ LIỆU MÔ PHỎNG** — số liệu dưới đây chỉ chứng minh đường ống chạy được, KHÔNG phải kết quả khoa học. Chạy lại trên PTB-XL thật rồi sinh lại báo cáo trước khi nộp.

# Phát hiện nhồi máu cơ tim cấp/cũ (MI) từ ECG 12 chuyển đạo trên PTB-XL

**Nhóm:** nhomXX · Thành viên: xem `submission.json` (định danh bằng MSSV)

## 1. Đặt vấn đề và ý nghĩa lâm sàng

Nhồi máu cơ tim (MI) là hoại tử cơ tim do thiếu máu cục bộ; ECG 12 chuyển đạo là xét nghiệm đầu tay vì nhanh, rẻ và không xâm lấn
[@thygesen2018universal]. Dấu hiệu điển hình gồm chênh lên/xuống đoạn ST, sóng Q bệnh lý và biến đổi sóng T ở các chuyển đạo thuộc cùng một vùng
cơ tim (thành trước: V1–V4; thành dưới: II, III, aVF; thành bên: I, aVL, V5–V6). Việc đọc ECG phụ thuộc kinh nghiệm người đọc và dễ bỏ sót ở ca
tinh tế, nên hệ thống hỗ trợ chẩn đoán tự động có giá trị trong sàng lọc và ở nơi thiếu bác sĩ tim mạch.

**Bài toán:** phân loại nhị phân bản ghi ECG 10 giây, 12 chuyển đạo thành *MI* hay *bình thường (NORM)*.
**Mục tiêu:** (i) xây dựng baseline dựa trên đặc trưng lâm sàng có thể giải thích; (ii) huấn luyện CNN 1D end-to-end;
(iii) so sánh công bằng giữa hai hướng với quy trình chống rò rỉ dữ liệu; (iv) đánh giá hiệu chuẩn, phân tầng theo nhóm bệnh nhân và giải thích mô hình.

## 2. Dữ liệu

Dùng **PTB-XL v1.0.3** [@wagner2020ptbxl], công khai trên PhysioNet [@goldberger2000physionet] (giấy phép CC BY 4.0), gồm ECG 12 chuyển đạo, 10 giây,
chuẩn bị ở 100 Hz và 500 Hz; bài này dùng bản **100 Hz** (1000 mẫu/chuyển đạo). Nhãn lấy từ `scp_codes` → `diagnostic_class`:
**MI** nếu có mã thuộc lớp MI; **NORM** nếu chỉ thuộc lớp NORM; các bản ghi thuộc lớp khác (STTC, CD, HYP) hoặc đa nhãn lẫn bị loại.
Do đó bài toán là *MI vs NORM* (không có hard negatives như STTC), điều này làm kết quả lạc quan hơn tình huống lâm sàng thật (xem mục 5).

Sau lọc còn **1200** bản ghi của **674** bệnh nhân (MI 38.0%). Tuổi 59.5 ± 14.9; nữ 50.2%.
Phân bố vùng MI: thành trước: 208, thành dưới: 174, vùng khác: 74.

| Tập | Fold (strat_fold) | Số bản ghi | Số bệnh nhân | MI (n) | MI (%) |
|---|---|---|---|---|---|
| Train | 1–8 | 973 | 549 | 368 | 37.8 |
| Val | 9 | 112 | 63 | 48 | 42.9 |
| Test | 10 | 115 | 62 | 40 | 34.8 |

**Kiểm tra rò rỉ bệnh nhân:** số bệnh nhân chung train–val / train–test / val–test = 0 / 0 / 0 (code `assert` bằng 0 trước khi huấn luyện).

## 3. Phương pháp

**3.1 Chống rò rỉ dữ liệu.** (a) Chia tập theo `strat_fold` chính thức của PTB-XL — các bản ghi cùng bệnh nhân nằm cùng một fold [@wagner2020ptbxl];
train = fold 1–8, val = fold 9, test = fold 10. (b) Mọi phép chuẩn hóa (trung bình/độ lệch chuẩn theo chuyển đạo, imputer, scaler) **chỉ fit trên train**.
(c) Siêu tham số, epoch tốt nhất và **ngưỡng quyết định (chỉ số Youden)** chọn trên val. (d) Test chỉ đánh giá một lần. (e) Không dùng SMOTE; mất cân bằng lớp xử lý bằng `class_weight`/`pos_weight`.

**3.2 Baseline đặc trưng lâm sàng.** Lọc thông cao 0.5 Hz (zero-phase) để bỏ trôi đường nền; dò đỉnh R bằng năng lượng băng 5–15 Hz; lấy **nhịp trung vị** (R−200 ms … R+500 ms);
tính cho mỗi chuyển đạo 5 đặc trưng so với đoạn PR: biên độ R, cực tiểu QRS, sóng Q, đoạn ST tại ~J+60 ms, sóng T (giá trị có biên độ lớn nhất), cộng nhịp tim, độ lệch chuẩn RR và số nhịp
(63 đặc trưng). Mô hình: Logistic Regression (chuẩn hóa, `C ∈ {0.01, 0.1, 1}`) và HistGradientBoosting (`max_depth ∈ {3, 6}`, `lr ∈ {0.05, 0.1}`), chọn theo AUROC trên val.

**3.3 CNN 1D.** Bốn khối Conv1D–BatchNorm–ReLU–MaxPool (32→64→128→128 kênh, kernel 7/7/5/5), Global Average Pooling, Dropout 0.3, đầu ra 1 logit. Loss BCE có `pos_weight`;
AdamW (lr 1e-3, weight decay 1e-4), cosine schedule, 30 epoch, batch 64; tăng cường dữ liệu: nhân biên độ ±10%, nhiễu Gaussian σ = 0.02 (đơn vị đã chuẩn hóa), dịch thời gian ±0.5 s; hạt giống 42.

**3.4 Đánh giá.** AUROC, AUPRC, độ nhạy, độ đặc hiệu, PPV, NPV, F1 tại ngưỡng cố định từ val; **khoảng tin cậy 95% bootstrap** (1000 lần, lấy mẫu lại bản ghi test);
hiệu chuẩn bằng Brier và ECE (10 bin). So sánh hai mô hình bằng bootstrap cặp trên hiệu AUROC. Phân tầng theo giới, nhóm tuổi và vùng MI (thành trước/dưới/khác).
Giải thích CNN bằng Grad-CAM [@selvaraju2017gradcam] và che từng chuyển đạo (occlusion).

## 4. Kết quả

Tập test: **115** bản ghi (MI = 40). Số trong ngoặc là khoảng tin cậy 95%.

| Mô hình | AUROC | AUPRC | Độ nhạy | Độ đặc hiệu | PPV | Brier | ECE |
|---|---|---|---|---|---|---|---|
| Logistic Regression (đặc trưng thủ công) | 0.986 (0.961–1.000) | 0.984 (0.955–1.000) | 0.975 (0.919–1.000) | 0.907 (0.838–0.971) | 0.848 (0.745–0.945) | 0.059 | 0.164 |
| Gradient Boosting (đặc trưng thủ công) | 0.985 (0.962–1.000) | 0.980 (0.951–1.000) | 0.725 (0.581–0.860) | 1.000 (1.000–1.000) | 1.000 (1.000–1.000) | 0.033 | 0.039 |

Mô hình chính (chọn theo AUROC trên **val**, không nhìn test): **Gradient Boosting (đặc trưng thủ công)**; ngưỡng 0.970 chọn trên val.

![Hình 1. Đường cong ROC trên tập test](../results_smoketest/fig_roc.png)

*Hình 1. Đường cong ROC trên tập test*

![Hình 2. Đường cong Precision–Recall trên tập test](../results_smoketest/fig_pr.png)

*Hình 2. Đường cong Precision–Recall trên tập test*

![Hình 3. Biểu đồ hiệu chuẩn](../results_smoketest/fig_calibration.png)

*Hình 3. Biểu đồ hiệu chuẩn*

![Hình 4. Ma trận nhầm lẫn của mô hình chính tại ngưỡng từ val](../results_smoketest/fig_confusion.png)

*Hình 4. Ma trận nhầm lẫn của mô hình chính tại ngưỡng từ val*


**So sánh HGB − LR:** ΔAUROC = -0.001 (95% CI -0.016 đến +0.016); khoảng tin cậy chứa 0 → chưa đủ bằng chứng để khẳng định hai mô hình khác nhau.

### 4.1 Phân tầng theo nhóm bệnh nhân (Gradient Boosting (đặc trưng thủ công))

| Nhóm | n | MI | AUROC (95% CI) | Độ nhạy tại ngưỡng |
|---|---|---|---|---|
| Giới: nam | 56 | 20 | 0.985 (0.953–1.000) | — |
| Giới: nữ | 59 | 20 | 0.985 (0.945–1.000) | — |
| Tuổi < 50 | 21 | 5 | 1.000 (1.000–1.000) | — |
| Tuổi 50–69 | 69 | 25 | 0.996 (0.984–1.000) | — |
| Tuổi ≥ 70 | 25 | 10 | 0.947 (0.843–1.000) | — |
| MI thành trước | — | 18 | 0.981 (0.945–1.000) | 0.722 |
| MI thành dưới | — | 15 | 0.983 (0.941–1.000) | 0.667 |
| MI vùng khác | — | 7 | 1.000 (1.000–1.000) | 0.857 |

(Với nhóm vùng MI, AUROC tính trên các ca MI vùng đó so với toàn bộ NORM của test; nhóm nhỏ → CI rộng, cần thận trọng khi diễn giải.)

### 4.2 Đặc trưng quan trọng của baseline

Logistic Regression (hệ số chuẩn hóa lớn nhất): `III_st` (+0.36), `II_st` (+0.35), `aVF_st` (+0.32), `V4_q` (-0.31), `V3_st` (+0.31), `V3_q` (-0.30).

Gradient Boosting (permutation importance trên val): `III_st` (0.013), `II_q` (0.013), `V3_q` (0.013), `V4_q` (0.012), `aVF_st` (0.012), `V2_st` (0.010).
Kỳ vọng lâm sàng: các đặc trưng đoạn ST, sóng Q và sóng T ở chuyển đạo của vùng tổn thương nên xuất hiện trong nhóm đứng đầu; nếu không, cần kiểm tra lại bước dò nhịp.

## 5. Thảo luận và hạn chế

**Nhận xét chính.** Trên tập test, mô hình có AUROC cao nhất là Logistic Regression (đặc trưng thủ công) (0.986 (0.961–1.000)). Hai hướng tiếp cận cho hiệu năng chưa khác biệt rõ ràng khi xét khoảng tin cậy bootstrap cặp.
Độ nhạy/độ đặc hiệu phụ thuộc ngưỡng; ngưỡng Youden từ val cân bằng hai chỉ số, còn ứng dụng sàng lọc có thể ưu tiên độ nhạy cao hơn.

**Hạn chế.**
1. *Bài toán dễ hơn thực tế:* chỉ MI vs NORM, đã loại STTC/CD/HYP — những dạng dễ nhầm với MI; hiệu năng ngoài thực tế (phân biệt MI với mọi ECG bất thường khác) thấp hơn.
2. *Nhãn không phải chuẩn vàng:* nhãn PTB-XL do bác sĩ/thuật toán gán từ ECG, không đối chiếu men tim hay chụp mạch vành; MI cũ và MI cấp gộp chung.
3. *Một nguồn dữ liệu:* PTB-XL thu thập tại một hệ thống với thiết bị Schiller trong những năm 1989–1996 [@wagner2020ptbxl]; chưa có kiểm định ngoài (ví dụ trên bộ dữ liệu khác) nên khả năng tổng quát hóa chưa được chứng minh.
4. *Một lần chia tập và một hạt giống:* CI bootstrap phản ánh sai số lấy mẫu test, không phản ánh biến thiên do khởi tạo/chia tập; nên lặp nhiều seed hoặc cross-validation theo fold nếu có thời gian.
5. *Nhóm con nhỏ:* phân tầng theo vùng MI/tuổi có CI rộng.
6. *Đặc trưng thủ công phụ thuộc dò nhịp:* ECG nhiễu có thể dò sai nhịp, làm sai đặc trưng ST/Q.
So sánh số liệu với benchmark [@strodthoff2021benchmark] chỉ mang tính tham khảo vì khác định nghĩa bài toán (nhị phân MI vs NORM so với phân loại siêu lớp).

## 6. Kết luận

Đã xây dựng đường ống tái lập được cho phát hiện MI từ ECG 12 chuyển đạo với chia tập theo bệnh nhân, chuẩn hóa chỉ trên train, ngưỡng chọn trên val, CI bootstrap, đánh giá hiệu chuẩn,
phân tầng nhóm bệnh nhân và giải thích mô hình. Hướng phát triển: kiểm định ngoài, bao gồm hard negatives (STTC/CD), mô hình dạng ResNet/Transformer với dữ liệu 500 Hz, nhiều seed, hiệu chuẩn sau huấn luyện (temperature scaling).

## 7. Đạo đức và tái lập

Chỉ dùng dữ liệu công khai PTB-XL (đã ẩn danh hóa; tuổi > 89 được PTB-XL mã hóa thành 300 và code đặt về NaN); không có PHI, khóa API hay dữ liệu bệnh nhân thật trong repo.
Dữ liệu không được commit — tải theo hướng dẫn trong `README.md`. Mô hình chỉ phục vụ nghiên cứu/học tập, **không phải thiết bị chẩn đoán**. Lệnh tái lập: `bash run_all.sh`; hạt giống 42.

## Tài liệu tham khảo

Các citekey trong báo cáo khớp `report/refs.bib`:
`wagner2020ptbxl` (Wagner et al., *Sci Data* 2020, doi:10.1038/s41597-020-0495-6) ·
`strodthoff2021benchmark` (Strodthoff et al., *IEEE JBHI* 2021, doi:10.1109/JBHI.2020.3022989) ·
`goldberger2000physionet` (Goldberger et al., *Circulation* 2000, doi:10.1161/01.CIR.101.23.e215) ·
`thygesen2018universal` (Thygesen et al., *Circulation* 2018, doi:10.1161/CIR.0000000000000617) ·
`selvaraju2017gradcam` (Selvaraju et al., *ICCV* 2017, doi:10.1109/ICCV.2017.74).
