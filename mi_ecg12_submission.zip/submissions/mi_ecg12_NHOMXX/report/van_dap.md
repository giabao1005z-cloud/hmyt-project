# Câu hỏi vấn đáp gợi ý (luyện trước buổi bảo vệ)

1. **Vì sao chia theo `strat_fold` mà không chia ngẫu nhiên theo bản ghi?** Một bệnh nhân có thể có nhiều ECG; chia theo bản ghi làm cùng bệnh nhân xuất hiện ở train và test → rò rỉ, AUROC phồng. `strat_fold` giữ mọi bản ghi của một bệnh nhân trong cùng fold; code có `assert` kiểm tra.
2. **Vì sao ngưỡng chọn trên val, không trên test?** Chọn ngưỡng trên test là dùng nhãn test để tối ưu → ước lượng độ nhạy/đặc hiệu lạc quan. Val dùng để chọn siêu tham số, epoch, ngưỡng; test chỉ đánh giá một lần.
3. **AUROC cao có đủ để triển khai lâm sàng không?** Không: bài toán MI vs NORM dễ hơn thực tế (đã loại STTC/CD/HYP), nhãn không phải chuẩn vàng, chưa kiểm định ngoài. Cần thêm hiệu chuẩn, PPV ở tỉ lệ bệnh thực tế và thử nghiệm tiền cứu.
4. **Vì sao báo cáo AUPRC, PPV bên cạnh AUROC?** AUROC không phản ánh tỉ lệ bệnh; PPV/AUPRC phụ thuộc prevalence nên cho thấy hiệu năng khi MI hiếm hơn trong dữ liệu PTB-XL.
5. **Vì sao dùng `pos_weight`/`class_weight` thay vì SMOTE?** SMOTE trên tín hiệu ECG tạo mẫu không thực tế và dễ gây rò rỉ nếu áp dụng trước khi chia tập; trọng số lớp đơn giản, không đổi dữ liệu.
6. **Khoảng tin cậy bootstrap cho biết điều gì, không cho biết điều gì?** Cho biết sai số lấy mẫu của tập test; không phản ánh biến thiên do seed hay cách chia tập — cần nhiều seed/CV để đánh giá.
7. **Baseline thắng/thua CNN thì giải thích thế nào?** Dùng kết quả ΔAUROC và CI bootstrap cặp trong báo cáo. Nếu CI chứa 0, nói rõ chưa đủ bằng chứng; thảo luận ưu điểm giải thích được của baseline.
8. **Grad-CAM có chứng minh mô hình "hiểu" MI không?** Không: chỉ cho thấy vùng thời gian ảnh hưởng đến đầu ra, không phải nhân quả; đối chiếu với occlusion chuyển đạo và kiến thức vùng MI (trước: V1–V4; dưới: II, III, aVF).
9. **Hiệu chuẩn là gì và vì sao quan trọng?** Xác suất dự đoán có khớp tần suất thực tế không (ECE, Brier). Bác sĩ dùng xác suất để ra quyết định nên cần đáng tin; có thể cải thiện bằng temperature scaling trên val.
10. **Nhóm con nào hiệu năng thấp hơn, vì sao?** Đọc bảng phân tầng (giới, tuổi, vùng MI); lưu ý nhóm nhỏ CI rộng; MI thành sau/bên khó thấy trên ECG thường.
11. **Dữ liệu có thông tin định danh không?** PTB-XL đã ẩn danh hóa; repo không chứa dữ liệu, khóa API; thành viên chỉ dùng MSSV.
12. **Nếu có thêm thời gian, cải thiện gì?** Kiểm định ngoài, thêm hard negatives, nhiều seed, ResNet/Transformer ở 500 Hz, temperature scaling.
