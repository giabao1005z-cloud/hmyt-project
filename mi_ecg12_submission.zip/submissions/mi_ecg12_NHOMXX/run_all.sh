#!/usr/bin/env bash
# Chạy toàn bộ đường ống trên PTB-XL thật và sinh báo cáo + slide từ kết quả.
# Dùng:  bash run_all.sh            (cần data/ptb-xl/)    |    bash run_all.sh --synthetic   (kiểm thử nhanh, dữ liệu mô phỏng)
set -euo pipefail
export PYTHONPATH="$(pwd)/src"
ARGS="${1:-}"; if [ "$ARGS" = "--synthetic" ]; then OUT=results_smoketest; SM="--smoke"; else OUT=results; SM=""; fi
python src/train_baseline.py --data data/ptb-xl --out $OUT $ARGS
python src/train_cnn.py      --data data/ptb-xl --out $OUT --epochs 30 $ARGS
python src/analyze.py        --data data/ptb-xl --out $OUT $ARGS
python src/gradcam.py        --data data/ptb-xl --out $OUT $ARGS
python src/make_report.py    --results $OUT --out report/report.md $SM
python slides/build_slides.py --results $OUT --out slides/slides.pptx $SM
echo "Xong. Kiểm tra: python scripts/validate_submission.py submissions/<topic_slug>_<ma_nhom>"
