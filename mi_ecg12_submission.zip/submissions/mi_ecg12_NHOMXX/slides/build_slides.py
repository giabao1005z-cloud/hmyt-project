"""Sinh slides/slides.pptx từ results/*.json và hình trong results/ (số liệu luôn khớp code).
Chạy: python slides/build_slides.py [--results results] [--smoke]"""
import argparse, json, os
from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN
from pptx.util import Inches, Pt

NAVY, RED, GREY, LIGHT = RGBColor(0x14, 0x24, 0x3D), RGBColor(0xC0, 0x39, 0x2B), RGBColor(0x55, 0x5B, 0x66), RGBColor(0xF4, 0xF6, 0xF8)
FONT = "Calibri"
LABEL = {"lr": "Logistic Regression", "hgb": "Gradient Boosting", "cnn": "CNN 1D"}


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--results", default="results"); ap.add_argument("--out", default="slides/slides.pptx")
    ap.add_argument("--smoke", action="store_true"); a = ap.parse_args(); R = a.results
    J = lambda f: json.load(open(f"{R}/{f}")) if os.path.exists(f"{R}/{f}") else None
    S, A = J("data_stats.json"), J("analysis.json")
    M = {n: J(f"{n}_metrics.json") for n in LABEL if J(f"{n}_metrics.json")}
    mm = A["main_model"]
    prs = Presentation(); prs.slide_width, prs.slide_height = Inches(13.333), Inches(7.5)
    blank = prs.slide_layouts[6]

    def tb(sl, x, y, w, h, text, size=18, bold=False, color=GREY, align=None):
        t = sl.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h)); tf = t.text_frame; tf.word_wrap = True
        for i, line in enumerate(text if isinstance(text, list) else [text]):
            p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
            p.text = line; p.font.size, p.font.bold, p.font.name = Pt(size), bold, FONT; p.font.color.rgb = color; p.space_after = Pt(10)
            if align: p.alignment = align
        return t

    def slide(title, notes=""):
        sl = prs.slides.add_slide(blank)
        bar = sl.shapes.add_shape(1, 0, 0, Inches(0.25), prs.slide_height); bar.fill.solid(); bar.fill.fore_color.rgb = RED; bar.line.fill.background()
        tb(sl, 0.7, 0.4, 12, 0.9, title, 30, True, NAVY)
        if a.smoke: tb(sl, 8.2, 7.0, 5, 0.4, "DỮ LIỆU MÔ PHỎNG — KHÔNG PHẢI KẾT QUẢ THẬT", 11, True, RED, PP_ALIGN.RIGHT)
        sl.notes_slide.notes_text_frame.text = notes
        return sl

    def bullets(sl, items, x=0.7, y=1.5, w=12, size=20):
        tb(sl, x, y, w, 5, ["•  " + i for i in items], size)

    def table(sl, rows, x, y, w, colw=None, size=14):
        t = sl.shapes.add_table(len(rows), len(rows[0]), Inches(x), Inches(y), Inches(w), Inches(0.45 * len(rows))).table
        for i, r in enumerate(rows):
            for j, v in enumerate(r):
                c = t.cell(i, j); c.text = str(v); p = c.text_frame.paragraphs[0]; p.font.size, p.font.name = Pt(size), FONT
                p.font.bold = i == 0; p.font.color.rgb = RGBColor(255, 255, 255) if i == 0 else GREY
                c.fill.solid(); c.fill.fore_color.rgb = NAVY if i == 0 else (LIGHT if i % 2 else RGBColor(255, 255, 255))
        if colw:
            for j, cw in enumerate(colw): t.columns[j].width = Inches(cw)

    def pic(sl, f, x, y, w=None, h=None):
        if os.path.exists(f"{R}/{f}"):
            sl.shapes.add_picture(f"{R}/{f}", Inches(x), Inches(y), Inches(w) if w else None, Inches(h) if h else None)

    # 1 Tiêu đề
    sl = prs.slides.add_slide(blank); bg = sl.background.fill; bg.solid(); bg.fore_color.rgb = NAVY
    tb(sl, 0.9, 2.2, 11.5, 1.6, "Phát hiện nhồi máu cơ tim từ ECG 12 chuyển đạo", 40, True, RGBColor(255, 255, 255))
    tb(sl, 0.9, 3.9, 11.5, 0.8, "Baseline đặc trưng lâm sàng so với CNN 1D trên PTB-XL", 22, False, RGBColor(0xDD, 0xE3, 0xEA))
    tb(sl, 0.9, 5.6, 11.5, 0.6, "Nhóm nhomXX  ·  Môn Hệ thống Y tế  ·  Dữ liệu công khai, không có PHI", 16, False, RGBColor(0xDD, 0xE3, 0xEA))
    if a.smoke: tb(sl, 0.9, 6.4, 11.5, 0.5, "BẢN XEM THỬ TRÊN DỮ LIỆU MÔ PHỎNG", 16, True, RGBColor(0xFF, 0x8A, 0x7A))
    sl.notes_slide.notes_text_frame.text = "Giới thiệu nhóm, bài toán và cấu trúc bài thuyết trình (~10 phút)."

    sl = slide("Vì sao cần hỗ trợ đọc ECG phát hiện MI?", "Nhấn mạnh ECG là xét nghiệm đầu tay; đọc ECG phụ thuộc kinh nghiệm; mô hình chỉ hỗ trợ, không thay bác sĩ.")
    bullets(sl, ["MI: hoại tử cơ tim do thiếu máu cục bộ; ECG 12 chuyển đạo nhanh, rẻ, không xâm lấn",
                 "Dấu hiệu: chênh ST, sóng Q bệnh lý, đổi sóng T ở nhóm chuyển đạo cùng vùng cơ tim",
                 "Ca tinh tế dễ bị bỏ sót → cần công cụ hỗ trợ sàng lọc",
                 "Bài toán: bản ghi ECG 10 giây → MI hay bình thường (NORM)"])

    tr, va, te = S["train"], S["val"], S["test"]
    sl = slide("Dữ liệu: PTB-XL (công khai, PhysioNet)", "PTB-XL là dữ liệu ẩn danh, CC BY 4.0. Chúng em dùng bản 100 Hz, nhãn MI vs NORM, loại các lớp khác.")
    bullets(sl, [f"{S['n_total']} bản ghi · {S['n_patients']} bệnh nhân · MI {100 * S['prevalence_MI']:.1f}% · 100 Hz · 12 chuyển đạo · 10 s",
                 "Nhãn từ scp_codes → diagnostic_class; bỏ STTC, CD, HYP và nhãn lẫn"], y=1.4, size=18)
    table(sl, [["Tập", "Fold", "Bản ghi", "Bệnh nhân", "MI (%)"],
               ["Train", "1–8", tr["n"], tr["n_patients"], f"{tr['MI_pct']:.1f}"],
               ["Val", "9", va["n"], va["n_patients"], f"{va['MI_pct']:.1f}"],
               ["Test", "10", te["n"], te["n_patients"], f"{te['MI_pct']:.1f}"]], 0.7, 3.3, 8.5, size=16)

    sl = slide("Thiết kế chống rò rỉ dữ liệu", "Đây là điểm rubric quan tâm: chia theo bệnh nhân, scaler fit trên train, ngưỡng chọn trên val, test dùng một lần, không SMOTE.")
    bullets(sl, ["Chia theo strat_fold chính thức: cùng bệnh nhân → cùng fold (assert 0 bệnh nhân chung giữa các tập)",
                 "Chuẩn hóa/imputer/scaler chỉ fit trên train",
                 "Siêu tham số, epoch và ngưỡng Youden chọn trên val",
                 "Test đánh giá đúng một lần; không dùng SMOTE (dùng class_weight)",
                 "Hạt giống cố định 42; mọi số liệu sinh tự động từ results/*.json"])

    sl = slide("Hai hướng tiếp cận", "Baseline giải thích được, CNN học trực tiếp từ tín hiệu.")
    tb(sl, 0.7, 1.4, 5.9, 0.5, "Baseline đặc trưng lâm sàng", 22, True, RED)
    tb(sl, 0.7, 2.0, 5.9, 4.5, ["•  Lọc 0.5 Hz, dò R, nhịp trung vị", "•  Mỗi chuyển đạo: R, Q, ST (J+60 ms), T", "•  63 đặc trưng", "•  Logistic Regression, Gradient Boosting"], 18)
    tb(sl, 6.9, 1.4, 5.9, 0.5, "CNN 1D end-to-end", 22, True, RED)
    tb(sl, 6.9, 2.0, 5.9, 4.5, ["•  4 khối Conv–BN–ReLU–MaxPool", "•  Global Average Pooling + Dropout", "•  BCE có pos_weight, AdamW, cosine", "•  Tăng cường: biên độ, nhiễu, dịch thời gian"], 18)

    sl = slide("Kết quả trên tập test (CI 95% bootstrap)", "Đọc bảng: AUROC, AUPRC, độ nhạy/đặc hiệu tại ngưỡng chọn trên val. Mô hình chính được chọn theo val, không theo test.")
    f = lambda m, k: f"{m['test'][k]:.3f} ({m['ci95'][k][0]:.3f}–{m['ci95'][k][1]:.3f})"
    table(sl, [["Mô hình", "AUROC", "AUPRC", "Độ nhạy", "Độ đặc hiệu"]] + [[LABEL[n], f(m, "auroc"), f(m, "auprc"), f(m, "sens"), f(m, "spec")] for n, m in M.items()], 0.7, 1.6, 12, [3.0, 2.6, 2.2, 2.1, 2.1], 15)
    c = A.get("compare")
    msg = f"Mô hình chính (chọn theo val): {LABEL[mm]}"
    if c: msg += f"  ·  ΔAUROC {c['a'].upper()}−{c['b'].upper()} = {c['diff']:+.3f} (95% CI {c['ci95'][0]:+.3f} đến {c['ci95'][1]:+.3f})"
    tb(sl, 0.7, 4.6, 12, 1.2, msg, 18, False, NAVY)

    sl = slide("Đường cong ROC và Precision–Recall", "So sánh các mô hình trên cùng tập test.")
    pic(sl, "fig_roc.png", 0.8, 1.5, h=5.2); pic(sl, "fig_pr.png", 7.0, 1.5, h=5.2)

    sl = slide("Hiệu chuẩn và ma trận nhầm lẫn", "ECE thấp nghĩa là xác suất dự đoán đáng tin; ma trận nhầm lẫn tính ở ngưỡng chọn trên val.")
    pic(sl, "fig_calibration.png", 0.8, 1.5, h=5.2); pic(sl, "fig_confusion.png", 7.4, 1.7, h=4.6)

    sl = slide(f"Phân tầng theo nhóm bệnh nhân ({LABEL[mm]})", "Nhóm nhỏ nên CI rộng; chú ý nhóm có hiệu năng thấp hơn để thảo luận về công bằng.")
    fa = lambda v: "—" if not v else f"{v[0]:.3f} ({v[1]:.3f}–{v[2]:.3f})"
    rows = [["Nhóm", "MI (n)", "AUROC (95% CI)", "Độ nhạy"]] + [[k, v["n_MI"], fa(v["auroc_ci"]), "—" if v.get("sens") is None else f"{v['sens']:.3f}"] for k, v in A["subgroups"].items()]
    table(sl, rows, 0.7, 1.5, 12, [4.2, 1.6, 3.6, 2.6], 14)

    sl = slide("Giải thích mô hình", "Grad-CAM cho biết thời điểm mô hình chú ý; occlusion cho biết chuyển đạo nào quan trọng. Đối chiếu với kiến thức lâm sàng về vùng MI.")
    if os.path.exists(f"{R}/fig_gradcam.png"):
        pic(sl, "fig_gradcam.png", 0.7, 1.4, w=8.2); pic(sl, "fig_lead_occlusion.png", 9.1, 1.6, w=4.0)
    elif "top_features" in M.get("lr", {}):
        bullets(sl, ["Đặc trưng quan trọng nhất của baseline (LR):"] + [f"{n}: {v:+.2f}" for n, v in M["lr"]["top_features"][:6]], size=18)

    sl = slide("Hạn chế", "Trung thực về hạn chế: đây là điểm cộng khi vấn đáp.")
    bullets(sl, ["Chỉ MI vs NORM, đã loại STTC/CD/HYP → lạc quan hơn thực tế",
                 "Nhãn không phải chuẩn vàng (không có men tim/chụp mạch); MI cũ và cấp gộp chung",
                 "Một nguồn dữ liệu, chưa kiểm định ngoài; một lần chia tập, một hạt giống",
                 "Nhóm con nhỏ → CI rộng; đặc trưng thủ công phụ thuộc dò nhịp"], size=20)

    sl = slide("Kết luận và hướng phát triển", "Nhắc lại: công cụ hỗ trợ nghiên cứu, không phải thiết bị chẩn đoán.")
    bullets(sl, [f"Đường ống tái lập, chống rò rỉ; mô hình chính (chọn theo val): {LABEL[mm]}, AUROC test {f(M[mm], 'auroc')}",
                 "Hướng tiếp: kiểm định ngoài, thêm hard negatives (STTC, CD), nhiều seed/CV theo fold",
                 "Nâng cấp mô hình (ResNet/Transformer, 500 Hz) và hiệu chuẩn sau huấn luyện",
                 "Mã nguồn, dữ liệu công khai và lệnh tái lập: xem README.md"], size=20)
    os.makedirs(os.path.dirname(a.out), exist_ok=True); prs.save(a.out); print("đã ghi", a.out)


if __name__ == "__main__":
    main()
